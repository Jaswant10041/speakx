const mongoose = require('mongoose');
const QuizModel = require('./models/QuizModel');
const data = require('./data.json');
require('dotenv').config();


mongoose.connect(process.env.DATABASE_URL)
    .then(() => console.log('MongoDB connected'))
    .catch((err) => console.log('Error connecting to MongoDB:', err));


function convertToObjectId(data) {
    if (data && data.$oid) {
        return new mongoose.Types.ObjectId(data.$oid);
    }
    return data;
}


const quizzes = data.map((quiz) => {
    if (quiz._id) quiz._id = convertToObjectId(quiz._id);
    if (quiz.siblingId) quiz.siblingId = convertToObjectId(quiz.siblingId);

    if (quiz.type === 'ANAGRAM' && !quiz.solution) {
        quiz.solution = 'No solution provided';
    }

   
    if (quiz.type === 'ANAGRAM' && (!quiz.blocks || quiz.blocks.length === 0)) {
        quiz.blocks = [];
    }

   
    if (quiz.type === 'MCQ' && (!quiz.options || quiz.options.length === 0)) {
        quiz.options = [];
    }

    return quiz;
});


QuizModel.insertMany(quizzes)
    .then(() => console.log('Data imported successfully'))
    .catch((err) => console.log('Error while storing data:', err))
    .finally(() => mongoose.connection.close());
